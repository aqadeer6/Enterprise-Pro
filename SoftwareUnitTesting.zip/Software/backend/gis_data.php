<?php
header('Content-Type: application/json');
require 'config.php';
session_start();

// Basic response setup, we'll fill this with assets if all goes well
$response = ['success' => false, 'assets' => []];

// Gotta make sure the user is logged in first
if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'Unauthorized';
    echo json_encode($response);
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user'; // Grab the role from session, default to 'user' if not set

// Fetch assets based on user role
if ($role === 'admin') {
    // Admins get the full view, no restrictions
    $stmt = $pdo->query("SELECT name, latitude AS lat, longitude AS lon, category FROM assets");
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Regular users only see their own stuff or what's shared with them
    $stmt = $pdo->prepare("
        SELECT DISTINCT a.name, a.latitude AS lat, a.longitude AS lon, a.category
        FROM assets a
        LEFT JOIN shared_datasets sd ON a.id = sd.dataset_id
        WHERE a.uploaded_by = ? OR sd.shared_with_user_id = ?
    ");
    $stmt->execute([$user_id, $user_id]);
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Everything worked, so send back the assets
$response['success'] = true;
$response['assets'] = $assets;

echo json_encode($response);
?>
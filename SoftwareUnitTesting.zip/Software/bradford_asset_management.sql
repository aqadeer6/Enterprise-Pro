-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 29, 2025 at 05:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bradford_asset_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  `category` enum('school','hospital','park','other') DEFAULT 'other',
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `name`, `latitude`, `longitude`, `category`, `uploaded_by`, `uploaded_at`) VALUES
(208, 'as', 53.815000, -1.735000, 'other', NULL, '2025-03-28 15:42:12'),
(209, 'New School', 53.800000, -1.760000, 'school', NULL, '2025-03-28 15:42:23'),
(210, 'New Hospital', 53.810000, -1.750000, 'hospital', NULL, '2025-03-28 15:42:23'),
(211, 'New Park', 53.790000, -1.740000, 'park', NULL, '2025-03-28 15:42:23'),
(212, 'New Library', 53.795000, -1.730000, 'other', NULL, '2025-03-28 15:42:23'),
(213, 'New Café', 53.815000, -1.735000, 'other', NULL, '2025-03-28 15:42:23'),
(214, 'New Museum', 53.820000, -1.745000, 'other', NULL, '2025-03-28 15:42:23'),
(215, 'New Cinema', 53.785000, -1.725000, 'other', NULL, '2025-03-28 15:42:23'),
(216, 'New Restaurant', 53.805000, -1.755000, 'other', NULL, '2025-03-28 15:42:23'),
(217, 'Bradford Royal Infirmary', 53.806000, -1.785000, 'other', 32, '2025-03-29 04:49:52'),
(218, 'St. Luke\'s Hospital', 53.784500, -1.756000, 'hospital', 32, '2025-03-29 04:49:52'),
(219, 'Eccleshill Community Hospital', 53.814000, -1.713500, 'hospital', 32, '2025-03-29 04:49:52'),
(220, 'Westbourne Green Community Hospital', 53.805000, -1.766500, 'hospital', 32, '2025-03-29 04:49:52'),
(221, 'Shipley Hospital', 53.833000, -1.776000, 'hospital', 32, '2025-03-29 04:49:52'),
(222, 'The Ridge Medical Practice', 53.773000, -1.748500, 'other', 32, '2025-03-29 04:49:52'),
(223, 'Tong Medical Practice', 53.774500, -1.713000, 'other', 32, '2025-03-29 04:49:52'),
(224, 'Wibsey Medical Centre', 53.766000, -1.784500, 'other', 32, '2025-03-29 04:49:52'),
(225, 'Saltaire Medical Practice', 53.837000, -1.790000, 'other', 32, '2025-03-29 04:49:52'),
(226, 'Thornton Medical Centre', 53.791500, -1.844000, 'other', 32, '2025-03-29 04:49:52'),
(227, 'Barkerend Health Centre', 53.799000, -1.741500, 'other', 32, '2025-03-29 04:49:52'),
(228, 'Manningham Health Centre', 53.805500, -1.768000, 'other', 32, '2025-03-29 04:49:52'),
(229, 'Horton Park Medical Practice', 53.788500, -1.765500, 'park', 32, '2025-03-29 04:49:52'),
(230, 'Idle Medical Centre', 53.830000, -1.738000, 'other', 32, '2025-03-29 04:49:52'),
(231, 'The Willows Medical Centre', 53.792000, -1.752500, 'other', 32, '2025-03-29 04:49:52'),
(232, 'Leylands Medical Centre', 53.801000, -1.747000, 'other', 32, '2025-03-29 04:49:52'),
(233, 'Clarendon Medical Centre', 53.796500, -1.755000, 'other', 32, '2025-03-29 04:49:52'),
(234, 'Ashcroft Surgery', 53.785500, -1.769000, 'other', 32, '2025-03-29 04:49:52'),
(235, 'Sunrise Medical Practice', 53.799500, -1.743000, 'other', 32, '2025-03-29 04:49:52'),
(236, 'Lister Surgery', 53.808000, -1.766000, 'other', 32, '2025-03-29 04:49:52');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `action` text NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `action`, `user_id`, `timestamp`) VALUES
(1, 'Action: upload_csv by user 1', 1, '2025-03-24 01:44:43'),
(2, 'Action: upload_csv by user 1', 1, '2025-03-24 02:00:10'),
(3, 'Action: upload_csv by user 1', 1, '2025-03-24 02:06:03'),
(4, 'Action: upload_csv by user 1', 1, '2025-03-24 02:11:10'),
(5, 'Action: upload_csv by user 1', 1, '2025-03-24 02:12:41'),
(6, 'Action: upload_csv by user 1', 1, '2025-03-24 02:17:08'),
(7, 'Action: upload_csv by user 1', 1, '2025-03-24 02:18:18'),
(8, 'Action: upload_csv by user 1', 1, '2025-03-24 02:20:32'),
(9, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:52:10'),
(10, 'Action: approve_user by user 1', 1, '2025-03-24 05:52:16'),
(11, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:53:49'),
(12, 'Action: approve_user by user 1', 1, '2025-03-24 05:53:51'),
(13, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:54:49'),
(14, 'Action: change_department by user 1', 1, '2025-03-24 05:56:48'),
(15, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:56:50'),
(16, 'Action: change_role by user 1', 1, '2025-03-24 05:57:01'),
(17, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:57:02'),
(18, 'Action: change_role by user 1', 1, '2025-03-24 05:57:11'),
(19, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:57:12'),
(20, 'Action: get_pending_users by user 1', 1, '2025-03-24 05:58:20'),
(21, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:03:34'),
(22, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:03:45'),
(23, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:15:58'),
(24, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:26:49'),
(25, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:28:04'),
(26, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:33:36'),
(27, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:37:23'),
(28, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:42:11'),
(29, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:42:15'),
(30, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:52:47'),
(31, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:53:14'),
(32, 'Action: get_pending_users by user 1', 1, '2025-03-24 06:56:11'),
(33, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:04:10'),
(34, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:04:14'),
(35, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:10:49'),
(36, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:10:53'),
(37, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:10:57'),
(38, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:11:02'),
(39, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:11:06'),
(40, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:12:14'),
(41, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:16:51'),
(42, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:17:36'),
(43, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:38:06'),
(44, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:38:40'),
(45, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:38:47'),
(46, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:38:57'),
(47, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:39:02'),
(48, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:39:06'),
(49, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:39:13'),
(50, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:39:42'),
(51, 'Action: get_pending_users by user 1', 1, '2025-03-24 07:40:15'),
(52, 'Action: decline_user by user 1', 1, '2025-03-24 07:40:17'),
(53, 'Action: get_pending_users by user 1', 1, '2025-03-25 00:51:59'),
(54, 'Action: get_pending_users by user 1', 1, '2025-03-25 00:52:07'),
(55, 'Action: get_pending_users by user 1', 1, '2025-03-25 00:52:13'),
(56, 'Action: get_pending_users by user 1', 1, '2025-03-25 00:52:22'),
(57, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:02:49'),
(58, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:02:57'),
(59, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:03:05'),
(60, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:03:13'),
(61, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:06:09'),
(62, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:06:57'),
(63, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:04'),
(64, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:06'),
(65, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:07'),
(66, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:07'),
(67, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:09'),
(68, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:10'),
(69, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:08:11'),
(70, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:08:51'),
(71, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:09:08'),
(72, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:10:26'),
(73, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:12:39'),
(74, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:14:40'),
(75, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:17:13'),
(76, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:18:13'),
(77, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:18:41'),
(78, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:18:42'),
(79, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:27:43'),
(80, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:28:15'),
(81, 'Action: decline_user by user 1', 1, '2025-03-25 01:28:25'),
(82, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:28:45'),
(83, 'Action: get_pending_users by user 1', 1, '2025-03-25 01:29:00'),
(84, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:04'),
(85, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:05'),
(86, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:11'),
(87, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:12'),
(88, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:12'),
(89, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:13'),
(90, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:36:13'),
(91, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:01'),
(92, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:02'),
(93, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:03'),
(94, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:03'),
(95, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:03'),
(96, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:04'),
(97, 'Action: update_accessibility by user 1', 1, '2025-03-25 01:38:05'),
(98, 'Action: get_user_profile by user 8', NULL, '2025-03-25 01:54:04'),
(99, 'Action: get_user_profile by user 8', NULL, '2025-03-25 01:57:11'),
(100, 'Action: update_profile_details by user 8', NULL, '2025-03-25 02:37:59'),
(101, 'Action: update_profile_details by user 8', NULL, '2025-03-25 02:38:20'),
(102, 'Action: update_profile_details by user 8', NULL, '2025-03-25 02:38:44'),
(103, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:22'),
(104, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:23'),
(105, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:23'),
(106, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:24'),
(107, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:24'),
(108, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:24'),
(109, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:25'),
(110, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:26'),
(111, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:27'),
(112, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:30'),
(113, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:30'),
(114, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:31'),
(115, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:31'),
(116, 'Action: update_accessibility by user 8', NULL, '2025-03-25 02:56:32'),
(117, 'Action: change_password by user 8', NULL, '2025-03-25 03:00:21'),
(118, 'Action: update_profile_details by user 8', NULL, '2025-03-25 03:12:01'),
(119, 'Action: update_profile_details by user 8', NULL, '2025-03-25 03:12:14'),
(120, 'Action: change_password by user 8', NULL, '2025-03-25 03:13:19'),
(121, 'Action: change_password by user 8', NULL, '2025-03-25 03:13:50'),
(122, 'Action: get_pending_users by user 1', 1, '2025-03-25 03:20:49'),
(123, 'Action: get_pending_users by user 1', 1, '2025-03-25 03:29:22'),
(124, 'Action: update_accessibility by user 1', 1, '2025-03-25 03:29:25'),
(125, 'Action: update_accessibility by user 1', 1, '2025-03-25 03:29:25'),
(126, 'Action: update_accessibility by user 1', 1, '2025-03-25 03:29:25'),
(127, 'Action: update_accessibility by user 1', 1, '2025-03-25 03:29:26'),
(128, 'Action: update_accessibility by user 1', 1, '2025-03-25 03:29:26'),
(129, 'Action: upload_csv by user 8', NULL, '2025-03-25 03:47:13'),
(130, 'Action: upload_csv by user 8', NULL, '2025-03-25 03:48:20'),
(131, 'Action: upload_csv by user 8', NULL, '2025-03-25 03:48:45'),
(132, 'Action: upload_csv by user 8', NULL, '2025-03-25 03:49:11'),
(133, 'Action: upload_individual by user 8', NULL, '2025-03-25 03:50:03'),
(134, 'Action: update_accessibility by user 8', NULL, '2025-03-25 03:51:27'),
(135, 'Action: update_accessibility by user 8', NULL, '2025-03-25 03:51:28'),
(136, 'Action: get_pending_users by user 1', 1, '2025-03-25 04:50:19'),
(137, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:14'),
(138, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:14'),
(139, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:15'),
(140, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:15'),
(141, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:16'),
(142, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:17'),
(143, 'Action: update_accessibility by user 8', NULL, '2025-03-25 05:29:17'),
(144, 'Action: upload_csv by user 8', NULL, '2025-03-25 05:30:28'),
(145, 'Action: upload_csv by user 1', 1, '2025-03-25 11:48:36'),
(146, 'Action: get_pending_users by user 1', 1, '2025-03-25 11:50:15'),
(147, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:50:38'),
(148, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:50:39'),
(149, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:50:40'),
(150, 'Action: upload_csv by user 1', 1, '2025-03-25 11:51:50'),
(151, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:29'),
(152, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:30'),
(153, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:31'),
(154, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:31'),
(155, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:32'),
(156, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:40'),
(157, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:40'),
(158, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:40'),
(159, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:40'),
(160, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:40'),
(161, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:41'),
(162, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:41'),
(163, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:41'),
(164, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:41'),
(165, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(166, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(167, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(168, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(169, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(170, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(171, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(172, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:42'),
(173, 'Action: update_accessibility by user 1', 1, '2025-03-25 11:52:43'),
(174, 'Action: get_pending_users by user 1', 1, '2025-03-25 11:52:52'),
(175, 'Action: get_pending_users by user 1', 1, '2025-03-25 11:53:22'),
(176, 'Action: get_pending_users by user 1', 1, '2025-03-25 11:53:34'),
(177, 'Action: get_pending_users by user 1', 1, '2025-03-25 11:53:44'),
(178, 'Action: update_profile_details by user 8', NULL, '2025-03-25 11:54:34'),
(179, 'Action: update_profile_details by user 8', NULL, '2025-03-25 11:54:48'),
(180, 'Action: update_profile_details by user 8', NULL, '2025-03-25 11:55:10'),
(181, 'Action: get_pending_users by user 1', 1, '2025-03-25 12:00:07'),
(182, 'Action: approve_user by user 1', 1, '2025-03-25 12:00:14'),
(183, 'Action: get_pending_users by user 1', 1, '2025-03-25 12:00:43'),
(184, 'Action: change_role by user 1', 1, '2025-03-25 12:00:51'),
(185, 'Action: get_pending_users by user 1', 1, '2025-03-25 12:00:53'),
(186, 'Action: change_role by user 1', 1, '2025-03-25 12:01:05'),
(187, 'Action: get_pending_users by user 1', 1, '2025-03-25 12:01:06'),
(188, 'Action: change_department by user 1', 1, '2025-03-25 12:01:19'),
(189, 'Action: get_pending_users by user 1', 1, '2025-03-25 12:01:20'),
(190, 'Action: update_profile_details by user 8', NULL, '2025-03-25 12:12:13'),
(191, 'Action: change_password by user 8', NULL, '2025-03-25 12:22:07'),
(192, 'Action: upload_csv by user 1', 1, '2025-03-25 15:04:13'),
(193, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:04:42'),
(194, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:05:00'),
(195, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:06'),
(196, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:06'),
(197, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:07'),
(198, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:08'),
(199, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:09'),
(200, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:10'),
(201, 'Action: update_accessibility by user 1', 1, '2025-03-25 15:05:10'),
(202, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:06:01'),
(203, 'Action: approve_user by user 1', 1, '2025-03-25 15:06:14'),
(204, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:06:34'),
(205, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:06:40'),
(206, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:06:49'),
(207, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:14:29'),
(208, 'Action: get_pending_users by user 1', 1, '2025-03-25 15:14:34'),
(209, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:56:59'),
(210, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:57:01'),
(211, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:57:01'),
(212, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:57:03'),
(213, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:57:03'),
(214, 'Action: get_pending_users by user 1', 1, '2025-03-27 00:57:10'),
(215, 'Action: get_pending_users by user 1', 1, '2025-03-27 00:58:03'),
(216, 'Action: approve_user by user 1', 1, '2025-03-27 00:58:06'),
(217, 'Action: change_department by user 1', 1, '2025-03-27 00:58:31'),
(218, 'Action: get_pending_users by user 1', 1, '2025-03-27 00:58:32'),
(219, 'Action: get_pending_users by user 1', 1, '2025-03-27 00:59:07'),
(220, 'Action: get_pending_users by user 1', 1, '2025-03-27 00:59:15'),
(221, 'Action: get_pending_users by user 1', 1, '2025-03-27 00:59:24'),
(222, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:59:40'),
(223, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:59:41'),
(224, 'Action: update_accessibility by user 1', 1, '2025-03-27 00:59:42'),
(225, 'Action: get_pending_users by user 1', 1, '2025-03-27 02:51:39'),
(226, 'Action: decline_user by user 1', 1, '2025-03-27 02:51:48'),
(227, 'Action: get_pending_users by user 1', 1, '2025-03-27 02:51:57'),
(228, 'Action: get_pending_users by user 1', 1, '2025-03-27 02:52:01'),
(229, 'Action: get_pending_users by user 1', 1, '2025-03-27 02:52:04'),
(230, 'Action: get_pending_users by user 1', 1, '2025-03-27 02:54:10'),
(231, 'Action: approve_user by user 1', 1, '2025-03-27 02:54:17'),
(232, 'Action: upload_individual by user 24', NULL, '2025-03-27 02:55:41'),
(233, 'Action: update_profile_details by user 24', NULL, '2025-03-27 02:56:11'),
(234, 'Action: change_password by user 24', NULL, '2025-03-27 02:56:41'),
(235, 'Action: upload_csv by user 24', NULL, '2025-03-27 02:57:21'),
(236, 'Action: get_pending_users by user 1', 1, '2025-03-27 03:23:23'),
(237, 'Action: get_pending_users by user 1', 1, '2025-03-27 03:23:46'),
(238, 'Action: get_pending_users by user 1', 1, '2025-03-27 03:23:49'),
(239, 'Action: get_pending_users by user 1', 1, '2025-03-27 03:23:54'),
(240, 'Action: get_pending_users by user 1', 1, '2025-03-27 03:23:56'),
(241, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:03:40'),
(242, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:03:48'),
(243, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:07:14'),
(244, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:08:54'),
(245, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:12:04'),
(246, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:12:07'),
(247, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:14:54'),
(248, 'Action: decline_user by user 1', 1, '2025-03-27 05:15:04'),
(249, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:15:55'),
(250, 'Action: approve_user by user 1', 1, '2025-03-27 05:15:57'),
(251, 'Action: upload_csv by user 1', 1, '2025-03-27 05:16:53'),
(252, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:02'),
(253, 'Action: change_role by user 1', 1, '2025-03-27 05:17:17'),
(254, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:18'),
(255, 'Action: change_department by user 1', 1, '2025-03-27 05:17:21'),
(256, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:22'),
(257, 'Action: change_role by user 1', 1, '2025-03-27 05:17:32'),
(258, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:34'),
(259, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:40'),
(260, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:43'),
(261, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:46'),
(262, 'Action: get_pending_users by user 1', 1, '2025-03-27 05:17:54'),
(263, 'Action: update_accessibility by user 1', 1, '2025-03-27 05:17:57'),
(264, 'Action: update_accessibility by user 1', 1, '2025-03-27 05:17:58'),
(265, 'Action: update_accessibility by user 1', 1, '2025-03-27 05:17:59'),
(266, 'Action: upload_csv by user 26', NULL, '2025-03-27 05:18:34'),
(267, 'Action: upload_individual by user 26', NULL, '2025-03-27 05:19:37'),
(268, 'Action: update_profile_details by user 26', NULL, '2025-03-27 05:19:56'),
(269, 'Action: change_password by user 26', NULL, '2025-03-27 05:20:14'),
(270, 'Action: get_pending_users by user 1', 1, '2025-03-28 04:38:17'),
(271, 'Action: update_accessibility by user 1', 1, '2025-03-28 04:45:27'),
(272, 'Action: update_accessibility by user 1', 1, '2025-03-28 04:45:27'),
(273, 'Action: update_accessibility by user 1', 1, '2025-03-28 04:45:28'),
(274, 'Action: update_accessibility by user 1', 1, '2025-03-28 04:45:29'),
(275, 'Action: update_accessibility by user 1', 1, '2025-03-28 04:45:29'),
(276, 'Action: upload_csv by user 1', 1, '2025-03-28 04:50:31'),
(277, 'Action: upload_csv by user 1', 1, '2025-03-28 05:00:13'),
(278, 'Action: get_pending_users by user 1', 1, '2025-03-28 05:00:42'),
(279, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:44:58'),
(280, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:45:00'),
(281, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:46:14'),
(282, 'Action: approve_user by user 1', 1, '2025-03-28 11:46:17'),
(283, 'Action: upload_csv by user 27', NULL, '2025-03-28 11:47:12'),
(284, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:49:38'),
(285, 'Action: approve_user by user 1', 1, '2025-03-28 11:49:41'),
(286, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:49:46'),
(287, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:51:43'),
(288, 'Action: decline_user by user 1', 1, '2025-03-28 11:51:46'),
(289, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:57:34'),
(290, 'Action: decline_user by user 1', 1, '2025-03-28 11:57:40'),
(291, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:57:43'),
(292, 'Action: get_pending_users by user 1', 1, '2025-03-28 11:59:44'),
(293, 'Action: approve_user by user 1', 1, '2025-03-28 11:59:49'),
(294, 'Action: upload_csv by user 32', 32, '2025-03-28 12:01:37'),
(295, 'Action: upload_csv by user 32', 32, '2025-03-28 12:02:20'),
(296, 'Action: upload_csv by user 32', 32, '2025-03-28 12:02:31'),
(297, 'Action: upload_csv by user 32', 32, '2025-03-28 12:02:35'),
(298, 'Action: upload_csv by user 32', 32, '2025-03-28 12:10:46'),
(299, 'Action: get_pending_users by user 1', 1, '2025-03-28 12:11:32'),
(300, 'Action: get_pending_users by user 1', 1, '2025-03-28 12:11:39'),
(301, 'Action: get_pending_users by user 1', 1, '2025-03-28 12:11:43'),
(302, 'Action: get_pending_users by user 1', 1, '2025-03-28 12:11:51'),
(303, 'Action: upload_csv by user 1', 1, '2025-03-28 15:39:59'),
(304, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:40:10'),
(305, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:40:18'),
(306, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:40:23'),
(307, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:40:27'),
(308, 'Action: change_department by user 1', 1, '2025-03-28 15:40:51'),
(309, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:40:52'),
(310, 'Action: change_role by user 1', 1, '2025-03-28 15:40:53'),
(311, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:40:54'),
(312, 'Action: update_accessibility by user 1', 1, '2025-03-28 15:41:08'),
(313, 'Action: update_accessibility by user 1', 1, '2025-03-28 15:41:09'),
(314, 'Action: update_accessibility by user 1', 1, '2025-03-28 15:41:09'),
(315, 'Action: update_accessibility by user 1', 1, '2025-03-28 15:41:10'),
(316, 'Action: update_accessibility by user 1', 1, '2025-03-28 15:41:10'),
(317, 'Action: change_role by user 1', 1, '2025-03-28 15:41:17'),
(318, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:41:18'),
(319, 'Action: upload_individual by user 27', NULL, '2025-03-28 15:42:12'),
(320, 'Action: upload_csv by user 27', NULL, '2025-03-28 15:42:23'),
(321, 'Action: update_profile_details by user 27', NULL, '2025-03-28 15:42:39'),
(322, 'Action: update_profile_details by user 27', NULL, '2025-03-28 15:42:56'),
(323, 'Action: change_password by user 27', NULL, '2025-03-28 15:43:10'),
(324, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:44:48'),
(325, 'Action: approve_user by user 1', 1, '2025-03-28 15:44:50'),
(326, 'Action: get_pending_users by user 1', 1, '2025-03-28 15:44:57'),
(327, 'Action: upload_csv by user 32', 32, '2025-03-29 04:49:52'),
(328, 'Action: update_accessibility by user 32', 32, '2025-03-29 04:55:18'),
(329, 'Action: update_accessibility by user 32', 32, '2025-03-29 04:56:07'),
(330, 'Action: get_pending_users by user 1', 1, '2025-03-29 04:56:34'),
(331, 'Action: get_pending_users by user 1', 1, '2025-03-29 04:56:38'),
(332, 'Action: get_pending_users by user 1', 1, '2025-03-29 04:56:46'),
(333, 'Action: get_pending_users by user 1', 1, '2025-03-29 04:56:52'),
(334, 'Action: get_pending_users by user 1', 1, '2025-03-29 15:09:51');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shared_datasets`
--

CREATE TABLE `shared_datasets` (
  `id` int(11) NOT NULL,
  `dataset_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `shared_with_user_id` int(11) NOT NULL,
  `shared_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `department` varchar(100) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `high_contrast` tinyint(1) DEFAULT 0,
  `font_size` enum('small','normal','large') DEFAULT 'normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `department`, `first_name`, `last_name`, `status`, `created_at`, `high_contrast`, `font_size`) VALUES
(1, 'admin', 'admin@bradford.gov.uk', '$2y$10$pOjFWzmYilG0LDg3tGoVZe.kemxQ78C3iIDvzx2J9.lZQwiWG0chq', 'admin', 'Department of Adult Social Care', 'Admin', 'User', 'approved', '2025-03-23 05:03:43', 0, 'normal'),
(32, 'hi', 'qadeerbutt888@icloud.com', '$2y$10$CW7D9ZZgHGIajME9Cj2bVeNoJg5zkJJdEsiFc2NKRiFL/6DDaFD1W', 'user', 'Department of Adult Social Care', 'hi', 'hi', 'approved', '2025-03-28 11:59:25', 0, 'normal'),
(33, 'hii', 'hipunjabi05@gmail.com', '$2y$10$A8i9.FwPw6Ybs/0qcvl6qO8CQpIji/XnTFeR4XrJwebtqh0Bmx9US', 'user', 'Department of Adult Social Care', 'hi', 'hih', 'approved', '2025-03-28 15:44:24', 0, 'normal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `shared_datasets`
--
ALTER TABLE `shared_datasets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dataset_id` (`dataset_id`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `shared_with_user_id` (`shared_with_user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=237;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=335;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `shared_datasets`
--
ALTER TABLE `shared_datasets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `shared_datasets`
--
ALTER TABLE `shared_datasets`
  ADD CONSTRAINT `shared_datasets_ibfk_1` FOREIGN KEY (`dataset_id`) REFERENCES `assets` (`id`),
  ADD CONSTRAINT `shared_datasets_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `shared_datasets_ibfk_3` FOREIGN KEY (`shared_with_user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

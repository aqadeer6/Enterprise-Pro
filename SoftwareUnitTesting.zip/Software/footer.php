<footer>
    <p>Council Switchboard: 01274 432111</p>
    <p>Council Address: Britannia House, Hall Ings, Bradford BD1 1HX</p>
    <button onclick="window.location.href = '/software/pages/privacy-policy.php'">Privacy Policy</button>
</footer>